
import atree.core.attacker.*;
import atree.core.attributes.*;
import atree.core.model.*;
import atree.core.nodes.*;
import atree.core.processes.*;
import atree.core.processes.actions.*;
import atree.core.processes.constraints.*;
import atree.core.variables.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class OpenSafe implements IAtreeModelBuilder {
	
	public OpenSafe(){
		System.out.println("Model builder instantiated");
	}
	public AtreeModel createModel(){
		
		AtreeModel model = new AtreeModel();		
		
		//////////////////
		/////Variables////
		//////////////////
		AtreeVariable AttackAttempts = model.addVariable("AttackAttempts", new Constant(0.0));
		
		
		/////////////
		////Nodes////
		/////////////
		AttackNode OpenSafe = new AttackNode("OpenSafe");
		model.addAttackNodeDefinition(OpenSafe);
		AttackNode BruteForce = new AttackNode("BruteForce");
		model.addAttackNodeDefinition(BruteForce);
		AttackNode OpenLock = new AttackNode("OpenLock");
		model.addAttackNodeDefinition(OpenLock);
		AttackNode GuessPIN = new AttackNode("GuessPIN");
		model.addAttackNodeDefinition(GuessPIN);
		AttackNode LearnPIN = new AttackNode("LearnPIN");
		model.addAttackNodeDefinition(LearnPIN);
		AttackNode LaserCutter = new AttackNode("LaserCutter");
		model.addAttackNodeDefinition(LaserCutter);
		AttackNode ForceOwner = new AttackNode("ForceOwner");
		model.addAttackNodeDefinition(ForceOwner);
		AttackNode FindOwner = new AttackNode("FindOwner");
		model.addAttackNodeDefinition(FindOwner);
		
		DefenseNode Reinforced = new DefenseNode("Reinforced");
		model.addDefenseNodeDefinition(Reinforced);
		
		CountermeasureNode Lockdown = new CountermeasureNode("Lockdown");
		model.addCountermeasureNodeDefinition(Lockdown,Arrays.asList(GuessPIN));
		
		
		/////////////////
		////Relations////
		/////////////////
		HashMap<String,Set<String>> orRelations = new HashMap<>(); 
		HashMap<String,Set<String>> andRelations = new HashMap<>(); 
		HashMap<String,Set<String>> knRelations = new HashMap<>(); 
		HashMap<String,Set<String>> oandRelations = new HashMap<>(); 
		HashMap<String,List<String>> childrenMap = new HashMap<>();
		HashMap<String,Integer> knChildren = new HashMap<>();
		childrenMap.put("set0",Arrays.asList("BruteForce","OpenLock"));
		childrenMap.put("set1",Arrays.asList("Reinforced"));
		childrenMap.put("set2",Arrays.asList("GuessPIN","LearnPIN"));
		childrenMap.put("set3",Arrays.asList("Lockdown"));
		childrenMap.put("set4",Arrays.asList("LaserCutter"));
		childrenMap.put("set5",Arrays.asList("FindOwner","ForceOwner"));
		orRelations.put("OpenSafe",new HashSet<>(Arrays.asList("set0")));
		orRelations.put("OpenLock",new HashSet<>(Arrays.asList("set3","set2")));
		orRelations.put("BruteForce",new HashSet<>(Arrays.asList("set1")));
		orRelations.put("Reinforced",new HashSet<>(Arrays.asList("set4")));
		oandRelations.put("LearnPIN",new HashSet<>(Arrays.asList("set5")));
		model.addAllRelations(orRelations,andRelations,knRelations,oandRelations,childrenMap,knChildren);
		
		//////////////////
		////Attributes////
		//////////////////
		AttributeDef Cost = new AttributeDef("Cost");
		model.addAttributeDef(Cost);
		Cost.setNodeValue(LaserCutter,200.0);
		Cost.setNodeValue(FindOwner,20.0);
		Cost.setNodeValue(ForceOwner,10.0);
		Cost.setNodeValue(Reinforced,250.0);
		
		/////////////////
		////Attackers////
		/////////////////
		Attacker clever = new Attacker ("clever");
		model.addAttacker(clever);
		
		/////////////////////////////
		////Defense Effectiveness////
		/////////////////////////////
		model.setDefenseEffectivenesss(model.getAttackers(), Arrays.asList(BruteForce),Reinforced,0.95);
		model.setDefenseEffectivenesss(model.getAttackers(), Arrays.asList(OpenLock),Lockdown,0.8);
		
		///////////////
		////Actions////
		///////////////
		NormalAction choose = new NormalAction("choose");
		model.addNormalAction(choose);
		NormalAction tryAction = new NormalAction("tryAction");
		model.addNormalAction(tryAction);
		NormalAction success = new NormalAction("success");
		model.addNormalAction(success);
		
		//////////////////////////////
		////Attack Detection Rates////
		//////////////////////////////
		BruteForce.setDetectionRate(0.5);
		OpenLock.setDetectionRate(0.1);
		GuessPIN.setDetectionRate(0.8);
		LearnPIN.setDetectionRate(0.3);
		LaserCutter.setDetectionRate(0.6);
		ForceOwner.setDetectionRate(0.7);
		FindOwner.setDetectionRate(0.6);
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		model.addConstraint(new DisequationOfAttributeExpressions(new Attribute(Cost),new Constant(250.0),AttributeExprComparator.LE));
		model.addConstraint(new DisequationOfAttributeExpressions(AttackAttempts,new Constant(15.0),AttributeExprComparator.LE));
		
		//////////////////////////
		////Action Constraints////
		//////////////////////////
		model.addActionConstraint(new ActionRequiresConstraint(new AddAction(LaserCutter), new DisequationOfAttributeExpressions(new Attribute(Cost),new Constant(100.0),AttributeExprComparator.LE)));
		model.addActionConstraint(new ActionRequiresConstraint(new FailAction(LaserCutter), new DisequationOfAttributeExpressions(new Attribute(Cost),new Constant(100.0),AttributeExprComparator.LE)));
		
		///////////////////////
		////Attack Diagrams////
		///////////////////////
		ProcessState start = new ProcessState("start");
		model.setInitialState(start);
		ProcessState finish = new ProcessState("finish");
		ProcessState stratForce = new ProcessState("stratForce");
		ProcessState stratF_OpenSafe = new ProcessState("stratF_OpenSafe");
		ProcessState stratF_BruteForce = new ProcessState("stratF_BruteForce");
		ProcessState stratF_LaserCutter = new ProcessState("stratF_LaserCutter");
		ProcessState stratLearnPIN = new ProcessState("stratLearnPIN");
		ProcessState stratLP_OpenSafe = new ProcessState("stratLP_OpenSafe");
		ProcessState stratLP_OpenLock = new ProcessState("stratLP_OpenLock");
		ProcessState stratLP_LearnPIN = new ProcessState("stratLP_LearnPIN");
		ProcessState stratLP_ForceOwner = new ProcessState("stratLP_ForceOwner");
		ProcessState stratLP_FindOwner = new ProcessState("stratLP_FindOwner");
		ProcessState stratGuessPIN = new ProcessState("stratGuessPIN");
		ProcessState stratGP_OpenSafe = new ProcessState("stratGP_OpenSafe");
		ProcessState stratGP_OpenLock = new ProcessState("stratGP_OpenLock");
		ProcessState stratGP_GuessPIN = new ProcessState("stratGP_GuessPIN");
		start.addTransition(new ProcessTransition(2.0,choose,stratForce,new SideEffect[]{},new TrueConstraint()));
		start.addTransition(new ProcessTransition(1.0,choose,stratGuessPIN,new SideEffect[]{},new TrueConstraint()));
		start.addTransition(new ProcessTransition(10.0,choose,stratLearnPIN,new SideEffect[]{},new TrueConstraint()));
		stratForce.addTransition(new ProcessTransition(1.0,tryAction,stratF_BruteForce,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(BruteForce),new NotConstraintExpr(new HasNodeConstraint(BruteForce)),BooleanConnector.AND)));
		stratF_BruteForce.addTransition(new ProcessTransition(2.0,new AddAction(BruteForce),stratForce,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratF_BruteForce.addTransition(new ProcessTransition(5.0,new FailAction(BruteForce),stratForce,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratForce.addTransition(new ProcessTransition(2.0,tryAction,stratF_LaserCutter,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(LaserCutter),new NotConstraintExpr(new HasNodeConstraint(LaserCutter)),BooleanConnector.AND)));
		stratF_LaserCutter.addTransition(new ProcessTransition(2.0,new AddAction(LaserCutter),stratForce,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratF_LaserCutter.addTransition(new ProcessTransition(1.0,new FailAction(LaserCutter),stratForce,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratForce.addTransition(new ProcessTransition(10.0,tryAction,stratF_OpenSafe,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(OpenSafe),new NotConstraintExpr(new HasNodeConstraint(OpenSafe)),BooleanConnector.AND)));
		stratF_OpenSafe.addTransition(new ProcessTransition(10.0,new AddAction(OpenSafe),stratForce,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratF_OpenSafe.addTransition(new ProcessTransition(1.0,new FailAction(OpenSafe),stratForce,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratForce.addTransition(new ProcessTransition(100.0,tryAction,finish,new SideEffect[]{},new HasNodeConstraint(OpenSafe)));
		stratLearnPIN.addTransition(new ProcessTransition(1.0,tryAction,stratLP_FindOwner,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(FindOwner),new NotConstraintExpr(new HasNodeConstraint(FindOwner)),BooleanConnector.AND)));
		stratLP_FindOwner.addTransition(new ProcessTransition(1.0,new AddAction(FindOwner),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLP_FindOwner.addTransition(new ProcessTransition(3.0,new FailAction(FindOwner),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLearnPIN.addTransition(new ProcessTransition(1.0,tryAction,stratLP_ForceOwner,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(ForceOwner),new NotConstraintExpr(new HasNodeConstraint(ForceOwner)),BooleanConnector.AND)));
		stratLP_ForceOwner.addTransition(new ProcessTransition(2.0,new AddAction(ForceOwner),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLP_ForceOwner.addTransition(new ProcessTransition(3.0,new FailAction(ForceOwner),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLearnPIN.addTransition(new ProcessTransition(10.0,tryAction,stratLP_LearnPIN,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(LearnPIN),new NotConstraintExpr(new HasNodeConstraint(LearnPIN)),BooleanConnector.AND)));
		stratLP_LearnPIN.addTransition(new ProcessTransition(5.0,new AddAction(LearnPIN),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLP_LearnPIN.addTransition(new ProcessTransition(1.0,new FailAction(LearnPIN),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLearnPIN.addTransition(new ProcessTransition(10.0,tryAction,stratLP_OpenLock,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(OpenLock),new NotConstraintExpr(new HasNodeConstraint(OpenLock)),BooleanConnector.AND)));
		stratLP_OpenLock.addTransition(new ProcessTransition(10.0,new AddAction(OpenLock),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLP_OpenLock.addTransition(new ProcessTransition(1.0,new FailAction(OpenLock),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLearnPIN.addTransition(new ProcessTransition(10.0,tryAction,stratLP_OpenSafe,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(OpenSafe),new NotConstraintExpr(new HasNodeConstraint(OpenSafe)),BooleanConnector.AND)));
		stratLP_OpenSafe.addTransition(new ProcessTransition(10.0,new AddAction(OpenSafe),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLP_OpenSafe.addTransition(new ProcessTransition(1.0,new FailAction(OpenSafe),stratLearnPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratLearnPIN.addTransition(new ProcessTransition(100.0,tryAction,finish,new SideEffect[]{},new HasNodeConstraint(OpenSafe)));
		stratGuessPIN.addTransition(new ProcessTransition(1.0,tryAction,stratGP_GuessPIN,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(GuessPIN),new NotConstraintExpr(new HasNodeConstraint(GuessPIN)),BooleanConnector.AND)));
		stratGP_GuessPIN.addTransition(new ProcessTransition(1.0,new AddAction(GuessPIN),stratGuessPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratGP_GuessPIN.addTransition(new ProcessTransition(15.0,new FailAction(GuessPIN),stratGuessPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratGuessPIN.addTransition(new ProcessTransition(10.0,tryAction,stratGP_OpenLock,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(OpenLock),new NotConstraintExpr(new HasNodeConstraint(OpenLock)),BooleanConnector.AND)));
		stratGP_OpenLock.addTransition(new ProcessTransition(10.0,new AddAction(OpenLock),stratGuessPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratGP_OpenLock.addTransition(new ProcessTransition(1.0,new FailAction(OpenLock),stratGuessPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratGuessPIN.addTransition(new ProcessTransition(10.0,tryAction,stratGP_OpenSafe,new SideEffect[]{},new BooleanConstraintExpr(new AllowedNodeConstraint(OpenSafe),new NotConstraintExpr(new HasNodeConstraint(OpenSafe)),BooleanConnector.AND)));
		stratGP_OpenSafe.addTransition(new ProcessTransition(10.0,new AddAction(OpenSafe),stratGuessPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratGP_OpenSafe.addTransition(new ProcessTransition(1.0,new FailAction(OpenSafe),stratGuessPIN,new SideEffect[]{new SideEffect(AttackAttempts,new ArithmeticAttributeExpression(AttackAttempts,new Constant(1.0),ArithmeticOperation.SUM))},new TrueConstraint()));
		stratGuessPIN.addTransition(new ProcessTransition(100.0,success,finish,new SideEffect[]{},new HasNodeConstraint(OpenSafe)));
		
		///////////////////////
		////Initial Attacks////
		///////////////////////
		model.init(clever,Arrays.asList(FindOwner));
		
		return model;
	}
}
